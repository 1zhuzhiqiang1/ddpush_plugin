/**
 * Created by Administrator on 2017/2/23 0023.
 */
var myApp = new Framework7({});

/* Initialize views */
var mainView = myApp.addView('.view-main', {
    dynamicNavbar: true
});

var $$ = Dom7;

document.addEventListener('deviceready', onDeviceReady, false);
document.addEventListener("backbutton", eventBackButton, false);

document.addEventListener("ddpush.openNotification", function (data) {
    console.log("ddpush.openNotification: " + data);
});

function eventBackButton() {
    var currentPage = mainView.activePage.name;
    if (currentPage === 'index') {
        window.plugins.toast.showWithOptions({
            message: "再点击一次退出程序",
            duration: 1500, // ms
            position: "bottom",
            addPixelsY: -60
        });
        document.removeEventListener("backbutton", eventBackButton, false); //注销返回键
        //3秒后重新注册
        var intervalID = window.setInterval(
            function () {
                window.clearInterval(intervalID);
                document.addEventListener("backbutton", eventBackButton, false); //返回键
            }, 2000
        );
    } else {
        mainView.router.back();
    }
}

function onDeviceReady() {

}