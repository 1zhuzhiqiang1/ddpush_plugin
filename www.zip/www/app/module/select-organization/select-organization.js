(function () {
    myApp.onPageBeforeInit('select-organization', function () {
        $$('#open_organization').click(function () {
            window.plugins.AnywarePlugin.openOrganizationChoiceActivity(null, function (result) {
                console.log("open_organization :" + result);
            });
        });
    });
})();