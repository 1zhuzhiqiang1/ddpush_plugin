(function () {
    myApp.onPageBeforeInit('open-conversation', function () {
        $$('#open_conversation').click(function () {
            window.plugins.AnywarePlugin.openConversation({
                account: "chengsk"
            }, function (result) {
                console.log("open_conversation :" + result);
            });
        });
    });
})();