(function () {
    myApp.onPageBeforeInit('close-service', function () {
        $$('#close_service').click(function () {
            window.plugins.AnywarePlugin.stopService(null, function (result) {
                console.log("close_service :" + result);
            });
        });
    });
})();