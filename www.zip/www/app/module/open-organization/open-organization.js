(function () {
    myApp.onPageBeforeInit('open-organization', function () {
        $$('#open_organization').click(function () {
            window.plugins.AnywarePlugin.openOrganization(null, function (result) {
                console.log("open_organization :" + result);
            });
        });
    });
})();