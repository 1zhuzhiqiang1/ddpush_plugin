(function () {
    myApp.onPageBeforeInit('open-settings', function () {
        $$('#open_settings').click(function () {
            window.plugins.AnywarePlugin.openEcmSetting(null, function (result) {
                console.log("open_settings :" + result);
            });
        });
    });
})();