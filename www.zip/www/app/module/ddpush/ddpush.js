(function () {
    myApp.onPageBeforeInit('ddpush', function () {

        $$('#start_ddpush_service').click(function () {
            window.plugins.DDPushPlugin.connectDDPushServe({
                server_ip: "1.85.38.103",
                server_port: "60042",
                push_port: "60043",
                user_name: "qwe"
            }, function (result) {

            });
        });

        //发送通用消息
        $$('#btn_push_message').click(function () {
            window.plugins.DDPushPlugin.sendCommonMessage(null, function () {

            });
        });
    });
})();