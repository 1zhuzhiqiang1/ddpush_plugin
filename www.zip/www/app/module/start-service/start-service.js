(function () {
    myApp.onPageBeforeInit('start-service', function () {
        $$('#start_service').click(function () {
            window.plugins.AnywarePlugin.startService({
                Enterprise: "zyyc",
                LanServer: "10.92.80.55",
                LanPort: "9091",
                WanServer: "222.87.206.219",
                WanPort: "9091",
                UserName: "chengsk",
                UserPassword: "123456"
            }, function (data) {
                console.log("start_service: "+data);
            });
        });
    });
})();