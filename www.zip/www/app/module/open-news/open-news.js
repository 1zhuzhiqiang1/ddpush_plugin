(function () {
    myApp.onPageBeforeInit('open-news', function () {
        $$('#open_news').click(function () {
            window.plugins.AnywarePlugin.openMessageList(null, function (result) {
                console.log("open_news :" + result);
            });
        });
    });
})();