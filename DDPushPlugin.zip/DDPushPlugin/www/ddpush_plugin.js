var DDPushPlugin = function () {
    };

    // private plugin function

    DDPushPlugin.prototype.receiveMessage = {};
    DDPushPlugin.prototype.openNotification = {};
    DDPushPlugin.prototype.receiveNotification = {};

    // 错误回调
    DDPushPlugin.prototype.errorCallback = function (msg) {
        console.log('DDPush Callback Error: ' + msg)
    };

    // 调用本地方法
    DDPushPlugin.prototype.callNative = function (name, args, successCallback, errorCallback) {
        if (errorCallback) {
            cordova.exec(successCallback, errorCallback, 'DDPushPlugin', name, args)
        } else {
            cordova.exec(successCallback, this.errorCallback, 'DDPushPlugin', name, args)
        }
    };

    // Android方法开始
    // 清除通知
    DDPushPlugin.prototype.clearLocalNotifications = function () {
        this.callNative('clearLocalNotifications', [], null)
    };

    // 接收到消息
    DDPushPlugin.prototype.receiveMessageInAndroidCallback = function (data) {
        data = JSON.stringify(data);
        console.log('DDPushPlugin:receiveMessageInAndroidCallback: ' + data);
        this.receiveMessage = JSON.parse(data);
        cordova.fireDocumentEvent('ddpush.receiveMessage', this.receiveMessage)
    };

    // 打开通知
    DDPushPlugin.prototype.openNotificationInAndroidCallback = function (data) {
        data = JSON.stringify(data);
        console.log('DDPushPlugin:openNotificationInAndroidCallback: ' + data);
        this.openNotification = JSON.parse(data);
        cordova.fireDocumentEvent('ddpush.openNotification', this.openNotification)
    };

    // 清除通知
    DDPushPlugin.prototype.receiveNotificationInAndroidCallback = function (data) {
        data = JSON.stringify(data);
        console.log('DDPushPlugin:receiveNotificationInAndroidCallback: ' + data);
        this.receiveNotification = JSON.parse(data);
        cordova.fireDocumentEvent('ddpush.receiveNotification', this.receiveNotification)
    };

    // 连接 DDPush 服务器
    DDPushPlugin.prototype.connectDDPushServe = function (data, successCB) {
        this.callNative("connectDDPushServe", [data], successCB);
    };

    // 发送通用消息
    DDPushPlugin.prototype.sendCommonMessage = function (data, successCB) {
        this.callNative("sendCommonMessage", [data], successCB);
    };

    // Android方法结束

    if (!window.plugins) {
        window.plugins = {}
    }

    if (!window.plugins.jPushPlugin) {
        window.plugins.DDPushPlugin = new DDPushPlugin()
    }

    module.exports = new DDPushPlugin()