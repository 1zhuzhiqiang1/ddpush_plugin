package com.chinasofti.plugins.ddpushplugin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.chinasofti.plugins.ddpushplugin.service.OnlineService;
import com.chinasofti.plugins.ddpushplugin.utils.Params;
import com.chinasofti.plugins.ddpushplugin.utils.Util;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.ddpush.im.v1.client.appserver.Pusher;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DDPushPlugin extends CordovaPlugin {

    private boolean showToast = true;

    private final static List<String> methodList = Arrays.asList(
            "connectDDPushServe",
            "sendCommonMessage"
    );

    private ExecutorService threadPool = Executors.newFixedThreadPool(1);
    private static DDPushPlugin instance;
    private static Activity cordovaActivity;
    private static String TAG = "DDPushPlugin";

    private static boolean shouldCacheMsg = false;
    private static boolean isStatisticsOpened = false;    // 是否开启统计分析功能

    public static String notificationTitle;
    public static String notificationAlert;
    public static Map<String, Object> notificationExtras = new HashMap<String, Object>();

    public static String openNotificationTitle;
    public static String openNotificationAlert;
    public static Map<String, Object> openNotificationExtras = new HashMap<String, Object>();

    public DDPushPlugin() {
        instance = this;
    }

    // 通用方法
    private void showToast(final String msg) {
        if (showToast) {
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(cordova.getActivity(), msg, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        Log.i(TAG, "DDPush initialize.");
        super.initialize(cordova, webView);
        cordovaActivity = cordova.getActivity();
    }

    @Override
    public boolean execute(final String action, final JSONArray args, final CallbackContext callbackContext) throws JSONException {
        if (!methodList.contains(action)) {
            return false;
        }
        threadPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Method method = DDPushPlugin.class.getDeclaredMethod(action, JSONArray.class, CallbackContext.class);
                    method.invoke(DDPushPlugin.this, args, callbackContext);
                } catch (Exception e) {
                    Log.e(TAG, e.toString());
                }
            }
        });
        return true;
    }

    /**
     * 启动 ddpush 服务
     */
    protected void connectDDPushServe(JSONArray data, CallbackContext callbackContext) {
        showToast("connectDDPushServe");
        JSONObject jsonObject = data.optJSONObject(0);
        String server_ip = jsonObject.optString("server_ip");
        String server_port = jsonObject.optString("server_port");
        String push_port = jsonObject.optString("push_port");
        String user_name = jsonObject.optString("user_name");
        saveAccountInfo(server_ip, server_port, push_port, user_name);
        Intent startSrv = new Intent(cordovaActivity.getApplicationContext(), OnlineService.class);
        startSrv.putExtra("CMD", "RESET");
        cordovaActivity.startService(startSrv);
    }

    // 发送通用消息
    protected void sendCommonMessage(JSONArray data, CallbackContext callbackContext) {
        showToast("sendCommonMessage");
        SharedPreferences account = cordovaActivity.getSharedPreferences(Params.DEFAULT_PRE_NAME, Context.MODE_PRIVATE);
        String server_ip = account.getString(Params.SERVER_IP, "");
        String user_name = account.getString(Params.USER_NAME, "");
        String push_port = account.getString(Params.PUSH_PORT, "");
        Thread t = null;
        try {
            t = new Thread(new send0x10Task(cordovaActivity, server_ip, Integer.parseInt(push_port),
                    Util.md5Byte(user_name)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        t.start();
    }

    // 发送消息线程
    class send0x10Task implements Runnable {
        private Context context;
        private String serverIp;
        private int port;
        private byte[] uuid;

        send0x10Task(Context context, String serverIp, int port, byte[] uuid) {
            this.context = context;
            this.serverIp = serverIp;
            this.port = port;
            this.uuid = uuid;
        }

        public void run() {
            Pusher pusher = null;
            Intent startSrv = new Intent(context, OnlineService.class);
            startSrv.putExtra("CMD", "TOAST");
            try {
                boolean result;
                pusher = new Pusher(serverIp, port, 1000 * 5);
                result = pusher.push0x10Message(uuid);
                if (result) {
                    startSrv.putExtra("TEXT", "通用信息发送成功");
                } else {
                    startSrv.putExtra("TEXT", "发送失败！格式有误");
                }
            } catch (Exception e) {
                e.printStackTrace();
                startSrv.putExtra("TEXT", "发送失败！" + e.getMessage());
            } finally {
                if (pusher != null) {
                    try {
                        pusher.close();
                    } catch (Exception e) {
                    }
                }
            }
            context.startService(startSrv);
        }
    }

    /**
     * 保存账号信息
     */
    private void saveAccountInfo(String server_ip, String server_port, String push_port, String user_name) {
        SharedPreferences account = cordovaActivity.getSharedPreferences(Params.DEFAULT_PRE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = account.edit();
        editor.putString(Params.SERVER_IP, server_ip);
        editor.putString(Params.SERVER_PORT, server_port);
        editor.putString(Params.PUSH_PORT, push_port);
        editor.putString(Params.USER_NAME, user_name);
        editor.putString(Params.SENT_PKGS, "0");
        editor.putString(Params.RECEIVE_PKGS, "0");
        editor.apply();
    }

    public static void transmitMessageReceive(String message) {
        if (instance == null) {
            return;
        }
        String format = "window.plugins.jPushPlugin.receiveMessageInAndroidCallback(%s);";
        final String js = String.format(format, message);
        cordovaActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                instance.webView.loadUrl("javascript:" + js);
            }
        });
    }

    private static JSONObject getMessageObject(String message, Map<String, Object> extras) {
        JSONObject data = new JSONObject();
        try {
            data.put("message", message);
            JSONObject jExtras = new JSONObject();
            for (Map.Entry<String, Object> entry : extras.entrySet()) {
                if (entry.getKey().equals("cn.jpush.android.EXTRA")) {
                    JSONObject jo = null;
                    if (TextUtils.isEmpty((String) entry.getValue())) {
                        jo = new JSONObject();
                    } else {
                        jo = new JSONObject((String) entry.getValue());
                        String key;
                        Iterator keys = jo.keys();
                        while (keys.hasNext()) {
                            key = keys.next().toString();
                            jExtras.put(key, jo.getString(key));
                        }
                    }
                    jExtras.put("cn.jpush.android.EXTRA", jo);
                } else {
                    jExtras.put(entry.getKey(), entry.getValue());
                }
            }
            if (jExtras.length() > 0) {
                data.put("extras", jExtras);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }


    /**
     * 打开通知
     *
     * @throws JSONException
     */
    public static void transmitNotificationOpen(String message) {
        if (instance == null) {
            return;
        }
        JSONObject data = null;
        try {
            data = getNotificationObject(message);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String format = "window.plugins.DDPushPlugin.openNotificationInAndroidCallback(%s);";
        final String js = String.format(format, data.toString());
        cordovaActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                instance.webView.loadUrl("javascript:" + js);
            }
        });
        DDPushPlugin.openNotificationTitle = null;
        DDPushPlugin.openNotificationAlert = null;
    }

    /**
     * 接收到通知
     *
     * @throws JSONException
     */
    public static void transmitNotificationReceive(String message) {
        if (instance == null) {
            return;
        }
        JSONObject data = null;
        try {
            data = getNotificationObject(message);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String format = "window.plugins.DDPushPlugin.receiveNotificationInAndroidCallback(%s);";
        final String js = String.format(format, data.toString());
        cordovaActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                instance.webView.loadUrl("javascript:" + js);
            }
        });
        DDPushPlugin.notificationTitle = null;
        DDPushPlugin.notificationAlert = null;
    }

    /**
     * 获取通知对象
     *
     * @return
     * @throws JSONException
     */
    private static JSONObject getNotificationObject(String message) throws JSONException {
        JSONObject data = new JSONObject();
        try {
            data.put("msg", message);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        cordovaActivity = null;
        instance = null;
    }

}