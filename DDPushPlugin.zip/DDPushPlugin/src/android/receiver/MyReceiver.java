package com.chinasofti.plugins.ddpushplugin.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.chinasofti.plugins.ddpushplugin.DDPushPlugin;

public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getStringExtra("action");
        String msg = intent.getStringExtra("message");
        Log.i("DDPush", msg);
        if (action.equals("open")) {
            handlingNotificationOpen(context, msg);
        }
        Intent mainIntent = intent.getParcelableExtra("realIntent");
        mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(mainIntent);

    }

    private void handlingNotificationOpen(Context context, String message) {
//        DDPushPlugin.openNotificationTitle = title;
//        DDPushPlugin.openNotificationAlert = alert;
        DDPushPlugin.transmitNotificationOpen(message);
        Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        launch.addCategory(Intent.CATEGORY_LAUNCHER);
        launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(launch);
    }

    private void handlingMessageReceive(String msg) {
        DDPushPlugin.transmitMessageReceive(msg);
    }

    private void handlingNotificationReceive(Context context, String message) {
        Intent launch = context.getPackageManager().getLaunchIntentForPackage(
                context.getPackageName());
        launch.addCategory(Intent.CATEGORY_LAUNCHER);
        launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);

//        DDPushPlugin.notificationTitle = title;
//        DDPushPlugin.notificationAlert = alert;

        DDPushPlugin.transmitNotificationReceive(message);
    }
}